#ifndef __REQUEST_H__
#include "queue.h"
#include "stats.h"

void requestHandle(int fd, RequestStats in_stats);

#endif
